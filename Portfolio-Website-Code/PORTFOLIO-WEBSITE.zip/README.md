# Portfolio Website

A modern, responsive portfolio website built with Flask, HTML, CSS, and JavaScript.

## Features

- Responsive design that works on all devices
- Modern UI with smooth animations
- Skills section with animated progress bars
- Projects showcase with filtering functionality
- Contact form with email integration
- Professional timeline for experience

## Technologies Used

- **Backend**: Flask (Python)
- **Frontend**: HTML5, CSS3, JavaScript
- **Styling**: Custom CSS with CSS Grid and Flexbox
- **Icons**: Font Awesome
- **Fonts**: Google Fonts (Poppins)

## Installation

1. Clone this repository
2. Install Python 3.7 or higher
3. Install required packages:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the application:
   ```bash
   python app.py
   ```
5. Open your browser and visit `http://localhost:5000`

## Project Structure

```
PORTFOLIO-WEBSITE/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── static/
│   ├── css/
│   │   └── style.css     # Main stylesheet
│   ├── js/
│   │   └── script.js     # JavaScript functionality
│   ├── images/           # Project images
│   └── icons/            # Custom icons
├── templates/
│   ├── base.html         # Base template
│   ├── index.html        # Home page
│   ├── projects.html     # Projects page
│   └── contact.html      # Contact page
└── .vscode/
    └── launch.json       # VS Code debug configuration
```

## Customization

To customize this portfolio for your own use:

1. Update the `personal_info` dictionary in `app.py` with your information
2. Add your projects to the `projects` list in `app.py`
3. Replace the placeholder images with your own project screenshots
4. Configure email settings in the `send_email` route for the contact form
5. Update social media links throughout the templates

## Email Configuration

To enable the contact form email functionality:

1. Update the email settings in the `send_email` route in `app.py`
2. Use an app-specific password for Gmail
3. Make sure to enable 2-factor authentication on your email account

## Deployment

This Flask application can be deployed to platforms like:
- Heroku
- PythonAnywhere
- DigitalOcean
- AWS
- Google Cloud Platform

## License

This project is open source and available under the MIT License.

## Contact

For any questions or suggestions, please contact:
- Email: moiznuml604@gmail.com
- LinkedIn: https://linkedin.com/in/mzraj_22
- GitHub: https://github.com/moizraja0123
