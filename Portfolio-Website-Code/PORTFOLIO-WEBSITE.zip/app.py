from flask import Flask, render_template, request, jsonify
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

app = Flask(__name__)

# Your personal information
personal_info = {
    "name": "Moiz Raja",
    "title": "Web Developer & Machine Learning Engineer",
    "phone": "+923255523412",
    "email": "moiznuml604@gmail.com",
    "github": "https://github.com/moizraja0123",
    "linkedin": "https://linkedin.com/in/mzraj_22",
    "about": "I'm a passionate web developer and machine learning engineer with experience as a virtual assistant and call reviewer. I love creating innovative solutions that combine cutting-edge technology with user-friendly design.",
    "skills": [
        {"name": "Python", "level": 90},
        {"name": "JavaScript", "level": 85},
        {"name": "Machine Learning", "level": 80},
        {"name": "Flask/Django", "level": 85},
        {"name": "HTML/CSS", "level": 95},
        {"name": "Data Analysis", "level": 75}
    ]
}

# Sample projects data
projects = [
    {
        "id": 1,
        "title": "E-Commerce Platform",
        "description": "A full-stack e-commerce website with payment integration and admin dashboard.",
        "technologies": ["Python", "Flask", "JavaScript", "SQLite"],
        "image": "project-1.jpg",
        "link": "#"
    },
    {
        "id": 2,
        "title": "ML Price Prediction Model",
        "description": "Machine learning model that predicts housing prices based on various features.",
        "technologies": ["Python", "Scikit-learn", "Pandas", "Matplotlib"],
        "image": "project-2.jpg",
        "link": "#"
    },
    {
        "id": 3,
        "title": "Virtual Assistant Dashboard",
        "description": "Dashboard for managing virtual assistant tasks and client communications.",
        "technologies": ["Python", "JavaScript", "Chart.js", "Flask"],
        "image": "project-3.jpg",
        "link": "#"
    },
    {
        "id": 4,
        "title": "Call Review Analytics",
        "description": "Analytics platform for reviewing and analyzing customer service calls.",
        "technologies": ["Python", "D3.js", "Flask", "MongoDB"],
        "image": "project-4.jpg",
        "link": "#"
    }
]

@app.route('/')
def home():
    return render_template('index.html', info=personal_info, projects=projects[:3])

@app.route('/projects')
def projects_page():
    return render_template('projects.html', info=personal_info, projects=projects)

@app.route('/contact')
def contact():
    return render_template('contact.html', info=personal_info)

@app.route('/send_email', methods=['POST'])
def send_email():
    try:
        data = request.get_json()
        name = data.get('name')
        email = data.get('email')
        message = data.get('message')

        # Email configuration (you'll need to set up your email)
        sender_email = "your_email@gmail.com"
        receiver_email = "moiznuml604@gmail.com"
        password = "your_email_password"  # Use app-specific password for Gmail

        # Create message
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = f"Portfolio Contact: {name}"

        body = f"""
        Name: {name}
        Email: {email}
        Message: {message}
        """
        msg.attach(MIMEText(body, 'plain'))

        # Send email
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, password)
        text = msg.as_string()
        server.sendmail(sender_email, receiver_email, text)
        server.quit()

        return jsonify({"status": "success", "message": "Email sent successfully!"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
